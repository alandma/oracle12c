# Oracle Cloud Infrastructure Tools

The Docker images in this location can be used to create containers that
contain various command-line utilities to interact with Oracle Cloud
Infrastructure (OCI).

## Tools

The following tools are available as Docker images:

* [OCI Provider for Terraform](terraform-oci/)


