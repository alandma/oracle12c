# Update:

The GraalVM CE dockerfiles moved to: https://github.com/graalvm/container/tree/master/community
