#!/bin/sh

# run the script below to start php-fpm service

exec /tmp/php-fpm.sh
