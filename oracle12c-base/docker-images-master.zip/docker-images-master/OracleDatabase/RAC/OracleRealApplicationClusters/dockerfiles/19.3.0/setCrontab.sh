#!/bin/bash

* * * * * /tmp/reset_failed_units.sh
